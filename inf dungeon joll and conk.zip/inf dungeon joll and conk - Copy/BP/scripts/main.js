import { world, system, ItemStack, EquipmentSlot, EntityComponentTypes } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";

const START_BOOK = "infinity:start_book";
const DUNGEON_DIMENSION = "infinity:dungeon";
const OVERWORLD = "overworld";

const CLASSES = {
    joll: {
        name: "Joll (The Fighter)",
        tag: "class_joll",
        loadout: [
            { item: "minecraft:diamond_sword", slot: "mainhand" },
            { item: "minecraft:chainmail_chestplate", slot: "chest" }
        ],
        buffs: [{ effect: "strength", duration: 40, amplifier: 0 }]
    },
    conk: {
        name: "Conk (The Archer)",
        tag: "class_conk",
        loadout: [
            { item: "minecraft:bow", slot: "mainhand", enchantments: [{ id: "infinity", level: 1 }] },
            { item: "minecraft:arrow", slot: "inventory", count: 1 },
            { item: "minecraft:splash_potion", slot: "inventory", count: 16 }
        ],
        buffs: [{ effect: "resistance", duration: 40, amplifier: 0 }]
    },
    kibble: {
        name: "Kibble (The Freezer)",
        tag: "class_kibble",
        loadout: [
            { item: "minecraft:iron_sword", slot: "mainhand" },
            { item: "minecraft:diamond_boots", slot: "feet", enchantments: [{ id: "frost_walker", level: 1 }] }
        ],
        buffs: [{ effect: "speed", duration: 40, amplifier: 1 }, { effect: "jump_boost", duration: 40, amplifier: 1 }]
    },
    golem: {
        name: "Golem (The Tank)",
        tag: "class_golem",
        loadout: [
            { item: "minecraft:shield", slot: "offhand" },
            { item: "minecraft:iron_chestplate", slot: "chest" },
            { item: "minecraft:iron_leggings", slot: "legs" }
        ],
        buffs: [{ effect: "slowness", duration: 40, amplifier: 0 }, { effect: "health_boost", duration: 40, amplifier: 4 }]
    },
    buzz: {
        name: "The Buzz (Healer)",
        tag: "class_buzz",
        loadout: [
            { item: "minecraft:wooden_sword", slot: "mainhand" },
            { item: "minecraft:leather_chestplate", slot: "chest" }
        ],
        buffs: []
    }
};

let gameStarted = false;
let buzzUnlockedItem = false;

// Progression Tracking
let gameTicks = 0;
let gamePhase = 1;
// 15 mins = 18000 ticks. 30 mins = 36000. 45 mins = 54000. 60 mins = 72000.

world.afterEvents.worldInitialize.subscribe(() => {
    try { world.scoreboard.addObjective("infinity_tokens", "Infinity Tokens"); } catch (e) {}
});

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    if (event.initialSpawn && !player.hasTag("has_book")) {
        const inventory = player.getComponent(EntityComponentTypes.Inventory).container;
        inventory.addItem(new ItemStack(START_BOOK, 1));
        player.addTag("has_book");
        world.scoreboard.getObjective("infinity_tokens")?.setScore(player, 0);
    }
});

world.afterEvents.itemUse.subscribe((event) => {
    const player = event.source;
    
    if (event.itemStack.typeId === START_BOOK) {
        system.run(() => {
            if (!gameStarted) showLobbyMenu(player);
            else showUpgradeMenu(player);
        });
    }
    
    if (event.itemStack.typeId === "minecraft:blaze_rod" && event.itemStack.nameTag === "Healer Role Item") {
        system.run(() => {
            if (player.hasTag("class_buzz")) {
                const players = world.getAllPlayers();
                for (const p of players) p.addEffect("instant_health", 1, { amplifier: 1 });
                player.sendMessage("§aYou used the Healer Role Item to heal everyone! (Infinite uses)");
            }
        });
    }
});

function showLobbyMenu(player) {
    const form = new ActionFormData()
        .title("Infinity Dungeon Lobby")
        .body("Gather your party!")
        .button("📖 Wiki")
        .button("🎭 Select Class")
        .button("⚔️ START GAME");

    form.show(player).then((response) => {
        if (response.canceled) return;
        if (response.selection === 0) showWiki(player);
        else if (response.selection === 1) showClassSelection(player);
        else if (response.selection === 2) startGame(player);
    });
}

function showWiki(player) {
    const wikiForm = new MessageFormData()
        .title("Infinity Dungeon Wiki")
        .body("Classes:\n- Joll: Fighter\n- Conk: Archer\n- Kibble: Freezer\n- Golem: Tank\n- Buzz: Healer\n\nProgression:\nSurvive the 1-hour campaign! Face Fire Spiders, and defeat the Ultimate Dungeon Team!")
        .button1("Back")
        .button2("Close");

    wikiForm.show(player).then((response) => {
        if (!response.canceled && response.selection === 0) showLobbyMenu(player);
    });
}

function showClassSelection(player) {
    const form = new ActionFormData()
        .title("Class Selection")
        .body("Choose your character:");
    const classKeys = Object.keys(CLASSES);
    for (const key of classKeys) form.button(CLASSES[key].name);

    form.show(player).then((response) => {
        if (response.canceled) return;
        const selectedKey = classKeys[response.selection];
        const selectedClass = CLASSES[selectedKey];
        for (const key of classKeys) player.removeTag(CLASSES[key].tag);
        player.addTag(selectedClass.tag);
        player.sendMessage(`§aYou have selected ${selectedClass.name}!`);
    });
}

function startGame(host) {
    gameStarted = true;
    gameTicks = 0;
    gamePhase = 1;
    world.sendMessage("§l§eThe Infinity Dungeon is starting! Phase 1: Deep Descent");

    const dungeonDim = world.getDimension(DUNGEON_DIMENSION);
    const players = world.getAllPlayers();

    for (const p of players) {
        p.teleport({ x: 0, y: 64, z: 0 }, { dimension: dungeonDim });
        let hasClass = false;
        for (const key in CLASSES) {
            if (p.hasTag(CLASSES[key].tag)) hasClass = true;
        }
        if (!hasClass) p.addTag(CLASSES.buzz.tag);
        setupPlayerLoadout(p);
    }
    system.runCommandAsync('scoreboard objectives setdisplay sidebar infinity_tokens');
}

function applyEnchantments(item, enchantments) {
    const encComponent = item.getComponent(EntityComponentTypes.Enchantable);
    if (encComponent) {
        for (const enc of enchantments) {
            try { encComponent.addEnchantment({ type: enc.id, level: enc.level }); } catch(e) {}
        }
    }
    return item;
}

function setupPlayerLoadout(player) {
    player.runCommandAsync('clear @s');
    const inventory = player.getComponent(EntityComponentTypes.Inventory).container;
    inventory.addItem(new ItemStack(START_BOOK, 1));

    const equippable = player.getComponent(EntityComponentTypes.Equippable);
    for (const key in CLASSES) {
        if (player.hasTag(CLASSES[key].tag)) {
            const cls = CLASSES[key];
            for (const gear of cls.loadout) {
                let item = new ItemStack(gear.item, gear.count || 1);
                if (gear.name) item.nameTag = gear.name;
                if (gear.enchantments) item = applyEnchantments(item, gear.enchantments);

                if (gear.slot === "mainhand") equippable.setEquipment(EquipmentSlot.Mainhand, item);
                else if (gear.slot === "offhand") equippable.setEquipment(EquipmentSlot.Offhand, item);
                else if (gear.slot === "head") equippable.setEquipment(EquipmentSlot.Head, item);
                else if (gear.slot === "chest") equippable.setEquipment(EquipmentSlot.Chest, item);
                else if (gear.slot === "legs") equippable.setEquipment(EquipmentSlot.Legs, item);
                else if (gear.slot === "feet") equippable.setEquipment(EquipmentSlot.Feet, item);
                else inventory.addItem(item);
            }
        }
    }
}

function repairItem(item) {
    if (!item) return;
    const dur = item.getComponent(EntityComponentTypes.Durability);
    if (dur && dur.damage > 0) dur.damage = 0;
}

// Fire Spider Logic
world.afterEvents.entityHitEntity.subscribe((event) => {
    if (!gameStarted) return;
    if (gamePhase >= 2 && event.damagingEntity.typeId === "minecraft:cave_spider") {
        if (event.hitEntity.typeId === "minecraft:player") {
            // Set player on fire for 3 seconds if hit by a fire spider
            event.hitEntity.setOnFire(60); 
        }
    }
});

// Phase Transitions
function checkPhaseTransition() {
    if (gamePhase === 1 && gameTicks >= 18000) {
        gamePhase = 2;
        world.sendMessage("§c§lPhase 2: The Fire Spiders! Watch out for their burning bite!");
    } else if (gamePhase === 2 && gameTicks >= 36000) {
        gamePhase = 3;
        world.sendMessage("§4§lPhase 3: The Ultimate Dungeon Team Appears! Brace yourselves!");
        spawnPhase3Bosses();
    } else if (gamePhase === 3 && gameTicks >= 54000) {
        gamePhase = 4;
        world.sendMessage("§5§lPhase 4: The Final Showdown! Ultimate Conk and Ultimate Golem have arrived!");
        spawnPhase4Bosses();
    } else if (gamePhase === 4 && gameTicks >= 72000) {
        gameStarted = false;
        world.sendMessage("§a§lVICTORY! You have conquered the Infinity Dungeon!");
        const players = world.getAllPlayers();
        for (const p of players) {
            p.teleport({ x: 0, y: 100, z: 0 }, { dimension: world.getDimension(OVERWORLD) });
        }
    }
}

function spawnPhase3Bosses() {
    const dungeonDim = world.getDimension(DUNGEON_DIMENSION);
    const players = world.getPlayers({ dimension: dungeonDim });
    if (players.length === 0) return;
    const loc = players[0].location;

    // Ultimate Joll (Vindicator)
    const joll = dungeonDim.spawnEntity("minecraft:vindicator", { x: loc.x + 5, y: 64, z: loc.z + 5 });
    joll.nameTag = "§cUltimate Joll";
    joll.addEffect("health_boost", 99999, { amplifier: 10, showParticles: false });
    joll.addEffect("instant_health", 1, { amplifier: 10 });
    joll.addEffect("speed", 99999, { amplifier: 1, showParticles: false });

    // Ultimate Kibble (Skeleton)
    const kibble = dungeonDim.spawnEntity("minecraft:skeleton", { x: loc.x - 5, y: 64, z: loc.z - 5 });
    kibble.nameTag = "§cUltimate Kibble";
    kibble.addEffect("health_boost", 99999, { amplifier: 5, showParticles: false });
    kibble.addEffect("instant_health", 1, { amplifier: 10 });
    kibble.addEffect("speed", 99999, { amplifier: 2, showParticles: false });
}

function spawnPhase4Bosses() {
    const dungeonDim = world.getDimension(DUNGEON_DIMENSION);
    const players = world.getPlayers({ dimension: dungeonDim });
    if (players.length === 0) return;
    const loc = players[0].location;

    // Ultimate Conk (Evoker)
    const conk = dungeonDim.spawnEntity("minecraft:evocation_illager", { x: loc.x + 5, y: 64, z: loc.z + 5 });
    conk.nameTag = "§5Ultimate Conk";
    conk.addEffect("health_boost", 99999, { amplifier: 10, showParticles: false });
    conk.addEffect("instant_health", 1, { amplifier: 10 });

    // Ultimate Golem (Iron Golem)
    const golem = dungeonDim.spawnEntity("minecraft:iron_golem", { x: loc.x - 5, y: 64, z: loc.z - 5 });
    golem.nameTag = "§5Ultimate Golem";
    golem.addEffect("health_boost", 99999, { amplifier: 20, showParticles: false });
    golem.addEffect("instant_health", 1, { amplifier: 20 });
    golem.addEffect("strength", 99999, { amplifier: 2, showParticles: false });
}

// Main Game Loop (20 ticks = 1 second)
system.runInterval(() => {
    if (!gameStarted) return;
    gameTicks++;
    
    // Check phase progression
    if (gameTicks % 20 === 0) { // Every second
        checkPhaseTransition();
    }

    const players = world.getAllPlayers();
    let anyoneHasGold = false;

    for (const p of players) {
        const inv = p.getComponent(EntityComponentTypes.Inventory).container;
        const equippable = p.getComponent(EntityComponentTypes.Equippable);

        // Infinite Durability
        repairItem(equippable.getEquipment(EquipmentSlot.Mainhand));
        repairItem(equippable.getEquipment(EquipmentSlot.Chest));
        repairItem(equippable.getEquipment(EquipmentSlot.Legs));
        repairItem(equippable.getEquipment(EquipmentSlot.Feet));

        // Buffs & Skills
        for (const key in CLASSES) {
            if (p.hasTag(CLASSES[key].tag)) {
                for (const buff of CLASSES[key].buffs) {
                    p.addEffect(buff.effect, buff.duration, { amplifier: buff.amplifier, showParticles: false });
                }
            }
        }
        
        // SKILLS
        if (p.hasTag("skill_unlocked")) {
            if (p.hasTag("class_joll")) { p.addEffect("strength", 40, { amplifier: 2, showParticles: false }); p.addEffect("resistance", 40, { amplifier: 1, showParticles: false }); }
            if (p.hasTag("class_conk")) p.addEffect("regeneration", 40, { amplifier: 1, showParticles: false });
            if (p.hasTag("class_kibble")) p.addEffect("speed", 40, { amplifier: 3, showParticles: false });
            if (p.hasTag("class_golem")) p.addEffect("absorption", 40, { amplifier: 2, showParticles: false });
            if (p.hasTag("class_buzz")) p.addEffect("regeneration", 40, { amplifier: 0, showParticles: false });
        }

        // Conk infinite ammo & potions
        if (p.hasTag("class_conk")) {
            p.runCommandAsync('enchant @s infinity 1');
            let hasArrow = false;
            let potionCount = 0;
            for (let i = 0; i < inv.size; i++) {
                const item = inv.getItem(i);
                if (item && item.typeId === "minecraft:arrow") hasArrow = true;
                if (item && item.typeId === "minecraft:splash_potion") potionCount += item.amount;
            }
            if (!hasArrow) inv.addItem(new ItemStack("minecraft:arrow", 1));
            if (potionCount < 8) inv.addItem(new ItemStack("minecraft:splash_potion", 8 - potionCount));
        }
        
        // Kibble Frost Walker & Freeze
        if (p.hasTag("class_kibble")) p.runCommandAsync('enchant @s frost_walker 1');

        // Check Gold
        if (!buzzUnlockedItem) {
            for (let i = 0; i < inv.size; i++) {
                const item = inv.getItem(i);
                if (item && (item.typeId === "minecraft:gold_ingot" || item.typeId === "minecraft:gold_nugget")) anyoneHasGold = true;
            }
        }
    }

    if (anyoneHasGold && !buzzUnlockedItem) {
        buzzUnlockedItem = true;
        world.sendMessage("§e§lSomeone found Gold! The Buzz unlocked the Healer Role Item!");
        for (const p of players) {
            if (p.hasTag("class_buzz")) {
                const inv = p.getComponent(EntityComponentTypes.Inventory).container;
                const healItem = new ItemStack("minecraft:blaze_rod", 1);
                healItem.nameTag = "Healer Role Item";
                inv.addItem(healItem);
                p.sendMessage("§aYou received the Healer Role Item!");
            }
        }
    }
}, 20);

// Spawning Loop (Mobs)
system.runInterval(() => {
    if (!gameStarted) return;
    const dungeonDim = world.getDimension(DUNGEON_DIMENSION);
    const players = world.getPlayers({ dimension: dungeonDim });
    if (players.length === 0) return;
    
    // Spawn more aggressively based on phase
    const spawnCount = gamePhase; 
    
    for (let i=0; i<spawnCount; i++) {
        const target = players[Math.floor(Math.random() * players.length)];
        const loc = target.location;
        const dx = (Math.random() - 0.5) * 40;
        const dz = (Math.random() - 0.5) * 40;
        
        let mobType = "minecraft:zombie";
        if (gamePhase >= 2 && Math.random() > 0.4) {
            mobType = "minecraft:cave_spider"; // Simulates Fire Spider
        } else if (Math.random() > 0.5) {
            mobType = "minecraft:cave_spider";
        }
        
        dungeonDim.spawnEntity(mobType, { x: loc.x + dx, y: 64, z: loc.z + dz });
    }
}, 100);

// entity death
world.afterEvents.entityDie.subscribe((event) => {
    if (!gameStarted) return;
    const killer = event.damageSource.damagingEntity;
    const deadEntity = event.deadEntity;

    if (killer && killer.typeId === "minecraft:player") {
        const obj = world.scoreboard.getObjective("infinity_tokens");
        if (obj) {
            const score = obj.getScore(killer) || 0;
            obj.setScore(killer, score + 1);
        }
        if (Math.random() < 0.20) {
            const dim = deadEntity.dimension;
            dim.spawnItem(new ItemStack("minecraft:gold_ingot", 1), deadEntity.location);
        }
    }

    // Boss death logic (give massive tokens)
    if (deadEntity.nameTag && deadEntity.nameTag.includes("Ultimate")) {
        world.sendMessage("§a§lAn Ultimate Boss has been defeated!");
        const players = world.getAllPlayers();
        for (const p of players) {
            const obj = world.scoreboard.getObjective("infinity_tokens");
            if (obj) {
                const score = obj.getScore(p) || 0;
                obj.setScore(p, score + 50);
                p.sendMessage("§e+50 Boss Tokens!");
            }
        }
    }
});

// Upgrade Menu
function showUpgradeMenu(player) {
    const obj = world.scoreboard.getObjective("infinity_tokens");
    const score = obj ? (obj.getScore(player) || 0) : 0;
    const isUnlocked = player.hasTag("skill_unlocked");
    const isOp = player.hasTag("host") || player.isOp();

    const form = new ActionFormData()
        .title("Upgrade Shop & Menu")
        .body(`Phase: ${gamePhase}\nTime: ${Math.floor(gameTicks/20)}s / 3600s\nTokens: ${score}\n\nChoose an option:`)
        .button("Upgrade Weapon (10 Tokens)")
        .button("Upgrade Armor (15 Tokens)")
        .button(isUnlocked ? "§aSkill Unlocked!" : "Unlock Class Skill (20 Tokens)");

    if (isOp) form.button("§c[Admin] Fast Forward Phase (+15 mins)");

    form.show(player).then((response) => {
        if (response.canceled) return;
        if (response.selection === 0) {
            if (score >= 10) { obj.setScore(player, score - 10); upgradeWeapon(player); } 
            else player.sendMessage("§cNot enough tokens!");
        } else if (response.selection === 1) {
            if (score >= 15) { obj.setScore(player, score - 15); upgradeArmor(player); } 
            else player.sendMessage("§cNot enough tokens!");
        } else if (response.selection === 2) {
            if (isUnlocked) player.sendMessage("§eYou already unlocked your class skill!");
            else if (score >= 20) {
                obj.setScore(player, score - 20);
                player.addTag("skill_unlocked");
                player.sendMessage("§a§lYou unlocked your Ultimate Class Skill!");
            } else player.sendMessage("§cNot enough tokens! You need 20.");
        } else if (response.selection === 3 && isOp) {
            gameTicks += 18000;
            player.sendMessage(`§cFast-forwarded 15 minutes! Ticks: ${gameTicks}`);
        }
    });
}

function upgradeWeapon(player) {
    const equippable = player.getComponent(EntityComponentTypes.Equippable);
    const mainhand = equippable.getEquipment(EquipmentSlot.Mainhand);
    if (mainhand) {
        if (mainhand.typeId.includes("wood")) equippable.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:stone_sword"));
        else if (mainhand.typeId.includes("stone")) equippable.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:iron_sword"));
        else if (mainhand.typeId.includes("iron")) equippable.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:diamond_sword"));
        else if (mainhand.typeId.includes("diamond")) equippable.setEquipment(EquipmentSlot.Mainhand, new ItemStack("minecraft:netherite_sword"));
        player.sendMessage("§aWeapon Upgraded!");
    }
}

function upgradeArmor(player) {
    const equippable = player.getComponent(EntityComponentTypes.Equippable);
    const chest = equippable.getEquipment(EquipmentSlot.Chest);
    if (chest) {
        if (chest.typeId.includes("leather")) equippable.setEquipment(EquipmentSlot.Chest, new ItemStack("minecraft:chainmail_chestplate"));
        else if (chest.typeId.includes("chainmail")) equippable.setEquipment(EquipmentSlot.Chest, new ItemStack("minecraft:iron_chestplate"));
        else if (chest.typeId.includes("iron")) equippable.setEquipment(EquipmentSlot.Chest, new ItemStack("minecraft:diamond_chestplate"));
        else if (chest.typeId.includes("diamond")) equippable.setEquipment(EquipmentSlot.Chest, new ItemStack("minecraft:netherite_chestplate"));
        player.sendMessage("§aArmor Upgraded!");
    }
}
