import sys
from youtube_transcript_api import YouTubeTranscriptApi
import json

def get_transcript(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id)
        # We'll just grab the text
        text = [t['text'] for t in transcript]
        with open('transcript.txt', 'w', encoding='utf-8') as f:
            f.write('\n'.join(text))
        print("Transcript saved to transcript.txt")
    except Exception as e:
        print("Error:", e)

if __name__ == '__main__':
    get_transcript("LK8AVO-DTmY")
